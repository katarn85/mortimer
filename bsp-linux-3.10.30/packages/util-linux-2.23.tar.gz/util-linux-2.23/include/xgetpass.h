#ifndef UTIL_LINUX_XGETPASS_H
#define UTIL_LINUX_XGETPASS_H

extern char *xgetpass(int pfd, const char *prompt);

#endif /* UTIL_LINUX_XGETPASS_H */
