#ifndef FDISK_COMMON_H
#define FDISK_COMMON_H

/* common stuff for fdisk, cfdisk, sfdisk */

extern char *partname(char *dev, int pno, int lth);

#endif /* FDISK_COMMON_H */
